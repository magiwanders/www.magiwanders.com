%HW1
% Elettrocardiogrammi
clear;

%load('ecg60hz.mat');
%load('ecghfn.mat');
load('ecglfn.mat');

%Hd = r360Hz;
%Hd = r3hf;
Hd = r3lf;

ecg_pulito=filter(Hd, ecg);
figure;
plot(t,ecg_pulito , '-');