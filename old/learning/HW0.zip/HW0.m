% HW0 - FENS 2019 - Simone Shawn Cazzaniga
%------------------------
% CONSEGNA

vett=zeros(1000,1);
for i=1:1000
    if i<100
        vett(i)=-1;
    else
    if i>900
        vett(i)=1;
    else
        vett(i)=sin(2*pi*(i-500)/1600);
end
end
end

rng('default');
vett1=randn(1000,1);
w=gausswin(50);
vett2=vett+conv(vett1,w,'same')/50;
%vett2(1:50) = 0;

% SVOLGIMENTO

f = 1; 
% f == 0 %-> Il programma esegue utilizzando il filtro FIR.
% f == 1 %-> Il programma esegue utilizzando il filtro IIR.

if f == 0
    % Filtro FIR Hamming Window con fir1
    Ft = 0.003;
    Bt = 0.001;
    delta1 = 0.1;
    delta2 = 0.1;
    N = ceil ((2/3)*log10(1/(10*delta1*delta2))*1/Bt);
    if rem(N,2)==0 N=N+1 
    end
    filter = fir1(N-1, Ft, 'low');
    %figure;
    %freqz(filter);
    %figure;
    %plot([1:length(filter)], filter, '.');
    %xlabel('Samples');
    %ylabel('Value');
    y=conv(vett2,filter, 'same');
else if f==1
   
    %IIR Butter
    Ft = 0.003;
    order = 3;
    [b, a] = butter(order, Ft);
    %[h,w] = freqz(b,a,1000);
    y = filtfilt(b, a, vett2);
    %figure;
    %freqz(b, a);

    end
end

figure;
plot([1:1000], vett, '.',[1:1000],vett2, '-',[1:1000],y , '*')
grid

%- Calcolo passaggio per zero
min_pos=2;
max_neg=-2;

for i=1:1000
    if y(i)<0 if y(i)>max_neg max_neg = y(i); max_neg_i=i; end 
    end
    if y(i)>=0 break 
    end
end

min_pos = y(i);
c=abs(max_neg)/(min_pos+abs(max_neg));
inters = max_neg_i + c;
delta_inters = inters - 500;

        
