load('Dati_input.mat');

% File dati alternativo 
a = zeros(1000,1);
for i=1:1000
    if i<=100
        a(i) = 0;
   end
   if i>100 & i<443
        a(i) = 0.003;
    end
    if i>=443 & i<=666
        a(i) = -0.001;
    end
    if i>666
        a(i) = 0;
    end
end
v = cumsum(a);
Dati_input = cumsum(v);

%v = gradient(Dati_input);
%a = gradient(v);
p = gradient(a);

[picchi, pos_picchi, width, proms] = findpeaks(abs(p),1,'MinPeakHeight',0.00001);


raggiunta_v1 = pos_picchi(1);
v1_to_v2_inizio_accel = pos_picchi(2);
raggiunta_v2 = pos_picchi(3);
