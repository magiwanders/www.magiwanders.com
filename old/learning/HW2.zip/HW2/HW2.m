% Caricamento e visualizzazione derivate dati non filtrati 
%load('Dati_input.mat');

% File dati alternativo 
%Dati_input = zeros(1000,1);
%for i=1:1000
%    if i<=100
%        Dati_input(i) = 0;
%   end
%   if i>100 & i<300
%        Dati_input(i) = Dati_input(i-1) + 1.2;
%    end
%    if i>=300 & i<=1000
%        Dati_input(i) = Dati_input(i-1) + 2;
%    end
%end


v_originale = gradient(Dati_input);
a_originale = gradient(v_originale);

figure
plot([1:1000], Dati_input, '.');

% Creazione filtro passabasso
n = 8;
attdB = 80;
Bt = 0.05;
[b,a] = cheby2(n, attdB, Bt);

% Applicazione del filtro correggendo il ritardo con filtfilt
dati_filtered = filtfilt(b, a, Dati_input);
v_filtrato_corretto = gradient(dati_filtered);
a_filtrato_corretto = gradient(v_filtrato_corretto);

% Ricostruzione istante in cui v1 diventa v2 - Seleziono tutti i picchi della funzione accelerazione
[picchi, pos_picchi] = findpeaks(abs(a_filtrato_corretto)); %trova tutti i picchi e le loro posizioni

% Seleziono solo i picchi rilevanti(quelli relativi al cambio di velocità)
picchi(picchi<0.02) = 0;

% Cancellazione delle oscillazioni di bordo. 
 for i=2:length(picchi)-1
    if ~((picchi(i-1) ~= 0 & picchi(i) == 0 & picchi(i+1) == 0) | (picchi(i-1) == 0 & picchi(i) ~= 0 & picchi(i+1) == 0) | (picchi(i-1) == 0 & picchi(i) == 0 & picchi(i+1) ~= 0)) | (i == length(picchi)-1)
        picchi(i-1) = 0;
        pos_picchi(i-1) = 0;
        picchi(i) = 0;
        pos_picchi(i) = 0;
        picchi(i+1) = 0;
        pos_picchi(i+1) = 0;
    end
end

tot_picchi = [picchi, pos_picchi];
tot_picchi = tot_picchi(any(tot_picchi,2),:);

% Partendo dagli indici dei picchi rilevanti in tot_picchi cerco i momenti
% in cui inizia e finisce di cambiare la velocità come i punti attorno al
% picco dove il valore dell'accelerazione scende sotto metà del valore del
% picco.

istanti_velocita = zeros(length(tot_picchi), 2);

for i=1:length(tot_picchi)
    % Ricerca inizio accelerazione
    for j=tot_picchi(i,2):-1:1 %indici di a_filtrato_corretto
        if a_filtrato_corretto(j) < (tot_picchi(i,1)/2)
            istanti_velocita(i,1) = j;
            break
        end
    end
    % Ricerca fine accelerazione
    for k=tot_picchi(i,2):length(a_filtrato_corretto) %indici di a_filtrato_corretto
        if a_filtrato_corretto(k+1) < (tot_picchi(i,1)/2)
            istanti_velocita(i,2) = k;
            break
        end
    end
end

figure
plot([1:1000], v_originale, '*', [1:1000], v_filtrato_corretto, '.');

figure
plot([1:1000], a_originale, '*', [1:1000], a_filtrato_corretto, '.');
        